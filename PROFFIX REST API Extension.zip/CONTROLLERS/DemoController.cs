﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using $safeprojectname$.PxRestApi;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("[controller]")]
    public class DemoController : ControllerBase
    {
        private readonly IPxRestApiClient pxRestApiClient;
        private readonly IConfiguration configuration;
        private readonly ILogger<DemoController> logger;

        public DemoController(IPxRestApiClient pxRestApiClient, IConfiguration configuration, ILogger<DemoController> logger)
        {
            this.pxRestApiClient = pxRestApiClient;
            this.configuration = configuration;
            this.logger = logger;
        }

        [HttpPost()]
        public async Task<IActionResult> OnEvent([FromBody] PxRestApiEvent<JObject> e)
        {
            string ereignisName = e?.Name;
            int laufNr = e?.Data?.Value<int>("Schluessel") ?? 0;
            string methode = e?.Data.Value<string>("Methode");
            string tabelle = e?.Data.Value<string>("Name");
            if (laufNr == 0 || string.IsNullOrEmpty(methode))
            {
                return BadRequest();
            }

            logger.LogInformation("Der Event {methode} wurde auf der Tabelle {tabelle} für den Schlüssel {laufNr} generiert (Ereignisname: {ereignisName}).", methode, tabelle, laufNr, ereignisName);

            var response = await pxRestApiClient.GetAsync($"pxapi/v4/ADR/Adresse/{laufNr}?depth=0");
            var jObject = (JObject)response.Body;

            var sb = new StringBuilder();
            foreach (var x in jObject)
            {
                sb.AppendLine($"{x.Key}: {x.Value}");
            }
            logger.LogInformation("{sb}", sb.ToString());

            if (response.StatusCode != 200)
            {
                logger.LogError("Die Adresse zum Schlüssel {laufNr} konnte nicht abgerufen werden (Status-Code: {StatusCode}).", laufNr, response.StatusCode);

                return BadRequest();
            }

            return NoContent();
        }
    }
}
