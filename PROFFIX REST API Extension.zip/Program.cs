﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.WindowsServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.IO;

namespace $safeprojectname$ {
    /// <summary>
    /// Klasse mit dem Eintrittspunkt.
    /// </summary>
    public class Program {
        /// <summary>
        /// Eintrittspunkt des Programms.
        /// </summary>
        /// <param name="args">Enthält die Kommandozeilenargumente.</param>
        public static int Main(string[] args) {
            try {
                var arguments = new ConfigurationBuilder()
                    .AddCommandLine(args)
                    .Build();

                string instanceName = arguments.GetValue<string>("instanceName");

                if (string.IsNullOrWhiteSpace(instanceName)) {
                    instanceName = "Development";
                }

                int port = arguments.GetValue<int>("port");

                if (port <= 0) {
                    port = 5000;
                }

                string contentRoot = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "PROFFIX REST API",
                    "Extension Instances",
                    instanceName);

                Directory.CreateDirectory(contentRoot);
                Directory.SetCurrentDirectory(contentRoot);

                var host = new WebHostBuilder()
                    .ConfigureAppConfiguration(configuration =>
                        configuration.SetBasePath(contentRoot)
                            .AddJsonFile("appsettings.json", true, true))
                    .ConfigureLogging(logging =>
                        logging.AddConsole())
                    .UseContentRoot(contentRoot)
                    .UseUrls($"http://localhost:{port}")
                    .UseKestrel(options =>
                        options.AddServerHeader = false)
                    .UseStartup<Startup>()
                    .Build();

                if (Environment.UserInteractive) {
                    host.Run();
                }
                else {
                    host.RunAsService();
                }

                return 0;
            }
            catch (Exception e) {
                Console.Error.WriteLine($"Die Anwendung konnte nicht gestartet werden ({e.Message}).");
                return 1;
            }
        }
    }
}
