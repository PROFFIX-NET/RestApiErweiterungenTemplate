﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.IO;

namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var arguments = new ConfigurationBuilder()
                    .AddCommandLine(args)
                    .Build();
                
                string instanceName = arguments.GetValue<string>("instanceName");

                if (string.IsNullOrWhiteSpace(instanceName))
                {
                    instanceName = "Development";
                }

                int port = arguments.GetValue<int>("port");

                if (port <= 0)
                {
                    port = 5000;
                }

                ConfigureLogger(instanceName);

                Log.Information("Starting up");
                CreateHostBuilder(args, port).Build().Run();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Application start-up failed");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        private static void ConfigureLogger(string instanceName)
        {
            var appSettingsFileName = "appsettings.json";
            string contentRoot = Path.Combine(
                                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                                "Proffix REST API",
                                "Extension Instances",
                                instanceName);
            Directory.CreateDirectory(contentRoot);
            Directory.SetCurrentDirectory(contentRoot);

            //Default Serilog Settings kopieren
            var sourceAppsettings = Path.Combine(AppContext.BaseDirectory, appSettingsFileName);
            var targetAppsettings = new FileInfo(Path.Combine(contentRoot, appSettingsFileName));
            if (!targetAppsettings.Exists)
            {
                File.Copy(sourceAppsettings, targetAppsettings.FullName);
            }

            //Serilog Konfiguration lesen
            var configuration = new ConfigurationBuilder()
                .SetBasePath(contentRoot)
                .AddJsonFile(appSettingsFileName, true)
                .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", true)
                .Build();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();
        }

        public static IHostBuilder CreateHostBuilder(string[] args, int port)
        {
            return Host
            .CreateDefaultBuilder(args)
            .UseSerilog()
            .UseWindowsService()
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseKestrel(kestrelOptions =>
                {
                    kestrelOptions.ListenAnyIP(port);
                    kestrelOptions.AddServerHeader = false;
                })
                .UseUrls()
                .UseStartup<Startup>();
            });

        }
    }
}
